# Detective Turnip and the Borrowed Hours

## 1. The Client

Mrs. Parsnip came to the office on a Tuesday, which Detective Turnip respected. Tuesdays were for work. So were the other six days, in his opinion, but Tuesday never pretended otherwise.

His office was a shelf in the root cellar of a house whose people had moved away, between the preserves and a crate marked FRAGILE that had contained nothing for years. On the door hung a sign he had lettered himself: T. TURNIP, INVESTIGATIONS. NO JOB TOO SMALL. NO SMALL TALK.

"Somebody is taking things from the cellar," said Mrs. Parsnip. She was old and pale and had run the place since before the shelf was a shelf. "Every night. One thing."

"Theft," said Turnip, and wrote it down.

"Here is the trouble. By morning it's back."

He stopped writing.

"Back," she said, "and slightly used. The plum jam, a spoonful lower. The candle stub, a thumb shorter. The fiddle that hangs by the stairs, with its strings still warm. Last night it was the tin of shoe polish. Somebody had been at it with real enthusiasm."

Turnip had worked eleven years without a day off. He had found lost buttons, exposed a ring of counterfeit radishes, and once talked a cabbage down off a high shelf. He had never met a thief who returned the goods.

"Why hire me, if nothing's gone?"

"Because something is going on in my cellar," said Mrs. Parsnip, "and I think you ought to be the one to find out what."

She paid in advance. That should have been his first clue.

## 2. The Creed

You should know what kind of turnip he was.

Upstairs, in the old days, people had turned their noses up at turnips. A turnip went into the stew when there was nothing better, and nobody thanked it. Turnip had decided early that there were two things a turnip could be for: the stew or the job. He chose the job, and he held on to it with everything he had, because he had seen what happened to vegetables that were no use to anybody.

So he rose early. He kept his notebook square to the edge of the desk. He ate standing. When the other residents asked him to things, he said he was on a case, and he generally was. He was tired a great deal, lately, in a way sleep did not seem to fix, and he took that as evidence of honest work.

## 3. The Witnesses

He began with the Onion brothers, who lived by the drain and cried at everything. They cried on the witness chair, on his notebook, and at one point on each other.

"We didn't see anything," sobbed the elder.

"We heard music," sobbed the younger, and his brother kicked him.

"Music," said Turnip.

"The pipes," said the elder. "The pipes sing. Old house."

Turnip wrote: *Onions. Lying. Badly.*

Next was Miss Beet, who sang torch songs on the pickle shelf and left a red print on everything she touched. Half the cellar wore the proof of her affections and seemed fine about it. Turnip examined the jam jar, the candle, the fiddle, and the polish tin. There was no red on any of them.

"So it wasn't me," said Miss Beet, with her chin on her hand. "Disappointed?"

"Relieved. You'd be a difficult arrest."

"Honey, I'd be the best arrest of your life." She looked him over. "Nice shoes, Detective."

He looked down. His shoes were gleaming. He did not remember polishing them, but he was a tidy root, and he supposed he had done it without thinking.

Last came Gerald, a mouse who bought and sold whatever fell behind the shelves. "Nobody's fencing jam," Gerald said. "Nobody's fencing anything. Whoever's got your stuff isn't in it for money." He hesitated. "Leave this one alone, Turnip. That's free. I never give anything away free, so think about that."

Three witnesses, and every one of them holding something back. In eleven years the cellar had never closed ranks against him. It stung more than he would have guessed.

## 4. The Coal Chute

The trail of small disturbances led to the old coal chute at the back, which nobody had used since the people left. Turnip went in with his lamp.

The dust on the floor was scuffed, and the scuffs made a pattern. They went round. They went round and round in loops that crossed and doubled back, as though someone had been pacing in circles for hours, or being chased, or losing their mind.

In the middle of the floor he found a drop of candle wax, a smear of plum, and one curl of peel. He held it to the lamp. It was white at one edge and purple at the other.

Turnip was the only turnip in the cellar.

He sat down on an upturned thimble and considered this in an orderly way. Somebody wanted the detective blamed. That explained the witnesses, who had been frightened or bought. It explained the warning. Somebody clever had gone to the trouble of shaving a turnip, which meant somebody had been close enough to him to do it, and he had not noticed.

His cuff was sticky. He had not noticed that either. The cellar was damp, he told himself, and went home to plan.

## 5. The Stakeout

For three nights Turnip did not sleep. He sat behind the FRAGILE crate with his lamp shuttered and watched the jam, the candle, the fiddle, and the tin.

Nothing moved. Nothing was taken. In the mornings the residents went by looking glum and short-tempered, and Miss Beet did not sing. The Onion brothers cried, though that proved nothing.

So the thief knew he was watching. The thief knew his habits, his hiding place, and his hours. Turnip had a short list of people who knew him that well, and it was shorter than he would have liked. It had one name on it. She had paid in advance.

On the fourth evening he laid his trap. He dusted the jam jar, the fiddle, and the polish tin with flour from the torn sack by the stairs, so finely that no eye would catch it. Whoever touched them would carry the proof away on their hands. Then he settled behind the crate to wait for Mrs. Parsnip.

He was so tired. He had been tired for years.

He closed his eyes to rest them.

## 6. The Proof

He woke in his own bed with the lamp burned out and morning coming gray through the grate.

He was furious with himself. He ran to the shelf. The jam was a spoonful lower. The fiddle strings were warm. The flour on all three was smudged with prints, clear as a signed confession.

Turnip smiled the small tight smile he permitted himself at the end of a case. Then he reached for his notebook, and saw his hands.

They were white to the wrist.

He stood there for some time. He looked at the prints on the jar, and at his hands, and at his shining shoes. He thought about the sticky cuff. He thought about the peel in the coal chute, which nobody had needed to shave from him, because it had come off the ordinary way, the way it does when a turnip is moving fast.

He thought about how tired he had been, for years, in a way sleep did not fix.

## 7. The Confession

Detective Turnip did the only thing he knew how to do. He walked to Mrs. Parsnip's shelf, set his notebook and his badge in front of her, and held out his floury hands.

"I've solved it," he said. "I'm the thief. I don't remember any of it, which is no defense. I've been stealing from this cellar in my sleep, and I've been useless to you as a detective. You'll want someone else for the job."

Mrs. Parsnip looked at the badge. Then she laughed until she had to hold on to the shelf.

"Stealing," she said. "Oh, you ridiculous root. Sit down."

He sat.

"Eleven years," she said. "Almost every night, around midnight, you get up with your eyes shut and you walk to the coal chute. You light the candle. You polish your shoes, and you are vain about it. You take down the fiddle, and Turnip, you play like the house is on fire. You eat jam off the spoon. And you dance. Those circles in the dust are a waltz. You're pretty good."

He could not speak.

"The whole cellar comes. The Onions cry at the slow ones. Miss Beet sings. Gerald runs a card game in the corner and cheats. It is the best thing that happens down here, and it happens because of you, and you are the only one in the cellar who has never been."

"They lied to me," Turnip said slowly. "All of them."

"They were scared. They thought if you found out, you'd arrest yourself and that would be the end of it. Which, I notice, is exactly what you tried to do. Three nights you sat up watching, and for three nights there was no music. Did you see their faces?"

He had. He had written it down as *glum*.

"Then why hire me?" he said. "If you knew. If everyone knew."

Mrs. Parsnip opened her drawer and took out a folded paper.

"I didn't have the idea," she said. "A fortnight ago this was under my door."

## 8. The Letter

It was in his own handwriting. The letters leaned a little, as if written in a hurry, or in the dark.

*Dear Mrs. Parsnip,*

*Please hire the detective. Pay him up front or he will get suspicious about the wrong thing.*

*He is very good and he will not stop until he finds me. I have tried leaving him clues for years. I shine his shoes. I leave jam on his cuff. He explains every one of them away, because he thinks a turnip has to be useful or it goes in the stew. He is the only one who can catch me, and I am so tired of him missing the party.*

*When he gets there, tell him this from me:*

*Play more. Your joy has value. Nobody down here loves you for the casework.*

*Also we are nearly out of jam.*

*— T.*

Turnip read it twice. Then he read it a third time, because a good detective checks his evidence, and because he could not see it very well.

## 9. Case Closed

That night he did not go to bed. At midnight he walked to the coal chute with his eyes open.

They were all there, and they went quiet when they saw he was awake. The younger Onion started crying in advance.

Turnip lit the candle. He took down the fiddle. It turned out that, awake, he played worse. He was stiff and he squeaked, and he kept stopping to apologize. Miss Beet told him to shut up and count to three. Somebody put a spoon of jam in his hand. By the second song he had stopped apologizing, and by the fourth he was going round in the dust with Mrs. Parsnip, who led.

Near dawn he sat on the upturned thimble with his shoes scuffed to ruin and opened his notebook one last time.

*Case of the Borrowed Hours,* he wrote. *Nothing stolen. Everything used. Culprit identified and released into his own custody.*

He thought for a moment, and added a line for the next detective, whoever that might be, reading along one page at a time and not peeking:

*You were right to wait for it. Now go and play.*
